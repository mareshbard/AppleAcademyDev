//
//  RemoteCharacter.swift
//  StarWarsApp
//
//  Created by User on 06/10/23.
//

import Foundation

struct RemoteCharacters: Decodable {
    let results: [Character]
}
struct Character: Decodable, Hashable {
    let name: String
    let img: String
    let level: String
}
