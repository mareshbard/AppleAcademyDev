//
//  RemoteCharacterLoader.swift
//  StarWarsApp
//
//  Created by User on 06/10/23.
//

import Foundation


 class RemoteCharacterLoader: ObservableObject {
    @Published var characters: [Character] = []

    @MainActor
    func fetchRemoteCharacters() async {
        
        let session = URLSession.shared
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase

        do {
            let (data, _) = try await session.data (
                for: URLRequest(url: URL(string: "https://digimon-api.vercel.app/api/digimon")!
                               )
            )
            
            let remoteCharacter = try decoder.decode([Character].self, from: data)
            self.characters = remoteCharacter
        } catch {
            print(error)
        }

    }
}

