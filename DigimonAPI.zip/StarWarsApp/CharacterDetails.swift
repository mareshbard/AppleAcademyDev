//
//  CharacterDetails.swift
//  StarWarsApp
//
//  Created by User on 06/10/23.
//

import SwiftUI

struct CharacterDetails: View {
    let character: Character
    @State var characterImage = Image("defaultImage")

    var body: some View {
  
            Text("DETALHES:")
            .navigationTitle("VEJA AQUI MAIS SOBRE CADA UM: ")
            .font(.system(size: 30))
            VStack {

                characterImage
                Text("Nome: \(character.name)").bold().fontWeight(.heavy)
                Text("Nível: \(character.level)").fontWeight(.heavy)
                
            }
            .task {
                self.characterImage = await UIImage.download(from: character.img)
            }
        
        
    }
}

