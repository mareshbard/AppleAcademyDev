//
//  StarWarsAppApp.swift
//  StarWarsApp
//
//  Created by User on 06/10/23.
//

import SwiftUI

@main
struct StarWarsAppApp: App {
    var body: some Scene {
        WindowGroup {
            CharacterList()
        }
    }
}
