//
//  ContentView.swift
//  StarWarsApp
//
//  Created by User on 06/10/23.
//


import SwiftUI

struct CharacterList: View {
    @ObservedObject var remoteCharacterLoader = RemoteCharacterLoader()

    var body: some View {
        Text("DIGIMON API:")
        .navigationTitle("DETALHES")
        .font(.system(size: 30))
        NavigationStack {
            List(remoteCharacterLoader.characters, id: \.self) { character in
                NavigationLink(destination: CharacterDetails(character: character)) {
                    CharacterRow(character: character)
                }
                .listRowSeparator(.hidden)
            } .padding()
            .listStyle(.plain)
        }
        .task {
            await remoteCharacterLoader.fetchRemoteCharacters()
        }
    }
}

                
                 
                 
      
