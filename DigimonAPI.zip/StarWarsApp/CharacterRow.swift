//
//  CharacterRow.swift
//  StarWarsApp
//
//  Created by User on 06/10/23.
//

import SwiftUI

struct CharacterRow: View {
    let character: Character
    @State var characterImage = Image("defaultImage")
    
    var body: some View {
        HStack {
            characterImage
                .resizable()
                .frame(width: 120, height: 120)
            Text(character.name)
            
        }
        .task {
            self.characterImage = await UIImage.download(from: character.img)
        }
    }
}

extension UIImage {
    static func download(from urlString: String) async -> Image {
        let url = URL(string: urlString)!
        let defaultImage = UIImage(named: "defaultImage")!

        do {
            let (data, _) = try await URLSession.shared.data(from: url)

            let uiImage = UIImage(data: data) ?? defaultImage

            return .init(uiImage: uiImage)
        } catch {
            print(error)
        }

        return Image(uiImage: defaultImage)
    }
}
